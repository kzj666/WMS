[{    
    "id":1,    
    "text":"Folder1", 
    "children":[{    
    	"id":11,    
        "text":"File1",    
        "checked":true   
    },{    
        "text":"Books",    
        "state":"open",    
            
        "children":[{    
        	"id":111,    
            "text":"<a onclick=\"NewTab('功能管理','../manage/functions.jsp')\">功能管理</a>"
        },{    
            "id": 8,    
            "text":"Sub Bookds",    
            "state":"closed"   
        }]    
    }]    
},{    
    "text":"Languages",    
    "state":"closed",    
    "children":[{    
        "text":"Java"   
    },{    
        "text":"C#"   
    }]    
}]  